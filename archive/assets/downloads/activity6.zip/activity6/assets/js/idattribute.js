function displayResult() {
    document.getElementById("myHeader").innerHTML = "Have a nice day!";
}